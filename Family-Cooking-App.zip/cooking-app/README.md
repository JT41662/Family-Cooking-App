# Family Favourites 🍽️

A family recipe manager with AI-powered suggestions.

**Live app:** https://jt41662.github.io/Family-Cooking-App/

## Features
- 📖 Store and browse your Family Favourites recipes
- 📄 Import recipes from a Word (.docx) document
- ✨ AI suggestions from your existing list (tracks history to avoid repeats)
- 🌟 Discover new recipe ideas outside your collection
- ➕ Add, edit, and delete recipes at any time

## Setup
```bash
npm install
npm run dev
```

## Deployment
Pushes to `main` automatically deploy to GitHub Pages via GitHub Actions.
