import { useState, useEffect, useRef } from "react";

// ─── Anthropic API helper ───────────────────────────────────────────────────
async function callClaude(systemPrompt, userMessage) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }],
    }),
  });
  const data = await res.json();
  return data.content.map((b) => b.text || "").join("\n");
}

// ─── Storage helpers ────────────────────────────────────────────────────────
const RECIPES_KEY = "familyFavourites";
const HISTORY_KEY = "suggestionHistory";

async function loadRecipes() {
  try {
    const r = await window.storage.get(RECIPES_KEY);
    return r ? JSON.parse(r.value) : [];
  } catch { return []; }
}
async function saveRecipes(recipes) {
  await window.storage.set(RECIPES_KEY, JSON.stringify(recipes));
}
async function loadHistory() {
  try {
    const r = await window.storage.get(HISTORY_KEY);
    return r ? JSON.parse(r.value) : [];
  } catch { return []; }
}
async function saveHistory(history) {
  await window.storage.set(HISTORY_KEY, JSON.stringify(history.slice(-30)));
}

// ─── Word doc parser (mammoth) ──────────────────────────────────────────────
async function parseDocx(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const mammoth = window.mammoth;
        if (!mammoth) { resolve(null); return; }
        const result = await mammoth.extractRawText({ arrayBuffer: e.target.result });
        resolve(result.value);
      } catch { resolve(null); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ─── Parse raw text into recipe objects via Claude ─────────────────────────
async function parseRecipesFromText(rawText) {
  const sys = `You are a recipe parser. Given raw text that may contain a list of recipes (possibly with ingredients and instructions), extract all recipes and return ONLY a JSON array. No markdown, no preamble.
Each recipe object must have:
  "name": string (recipe title),
  "ingredients": string (comma-separated or brief list, can be empty string),
  "instructions": string (brief steps, can be empty string),
  "tags": array of strings (e.g. ["dinner","chicken","quick"])
If the text is just a list of recipe names with no details, set ingredients and instructions to "".`;
  const raw = await callClaude(sys, `Parse these recipes:\n\n${rawText}`);
  try {
    const clean = raw.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch { return []; }
}

// ─── Suggest from family list ───────────────────────────────────────────────
async function suggestFromFamily(recipes, recentNames, count = 4) {
  const sys = `You are a helpful family meal planner. Given a list of recipes and recently suggested ones, pick ${count} varied suggestions. Return ONLY a JSON array of recipe names from the provided list. No markdown.`;
  const msg = `All recipes: ${recipes.map(r => r.name).join(", ")}\nRecently suggested (avoid repeating): ${recentNames.join(", ")}\nPick ${count} varied suggestions.`;
  const raw = await callClaude(sys, msg);
  try {
    const clean = raw.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch { return recipes.slice(0, count).map(r => r.name); }
}

// ─── Suggest NEW recipes (outside family list) ──────────────────────────────
async function suggestNewRecipes(existingNames, count = 4) {
  const sys = `You are a creative chef. Suggest ${count} new recipes that are NOT in the family's existing list. Return ONLY a JSON array of objects with "name", "description" (1 sentence), "tags" (array). No markdown.`;
  const msg = `Existing recipes to avoid: ${existingNames.join(", ")}\n\nSuggest ${count} exciting new recipes they haven't tried.`;
  const raw = await callClaude(sys, msg);
  try {
    const clean = raw.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch { return []; }
}

// ─── Icons ──────────────────────────────────────────────────────────────────
const Icon = ({ name, size = 18 }) => {
  const icons = {
    book: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
    wand: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 4-1 1"/><path d="m9 4 1 1"/><path d="m4 9 1 1"/><path d="m4 15 1-1"/><path d="M15 20l-1-1"/><path d="m9 20 1-1"/><path d="m20 9-1 1"/><path d="m20 15-1-1"/><path d="m14.5 9.5-5 5"/><path d="m9.5 9.5 5 5"/></svg>,
    star: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
    plus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    edit: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
    trash: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>,
    upload: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>,
    search: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    x: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    save: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>,
    refresh: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>,
  };
  return icons[name] || null;
};

// ─── Tag badge ───────────────────────────────────────────────────────────────
const Tag = ({ label }) => (
  <span style={{
    background: "rgba(180,140,100,0.15)", color: "#a0784a",
    borderRadius: 99, padding: "2px 10px", fontSize: 11, fontWeight: 600,
    letterSpacing: "0.04em", textTransform: "uppercase", border: "1px solid rgba(160,120,74,0.2)"
  }}>{label}</span>
);

// ─── Recipe Card ─────────────────────────────────────────────────────────────
const RecipeCard = ({ recipe, onEdit, onDelete }) => {
  const [open, setOpen] = useState(false);
  return (
    <div onClick={() => setOpen(!open)} style={{
      background: "rgba(255,252,245,0.9)", border: "1px solid rgba(200,180,140,0.3)",
      borderRadius: 14, padding: "18px 20px", cursor: "pointer",
      transition: "all 0.2s", boxShadow: open ? "0 8px 32px rgba(160,120,74,0.12)" : "0 2px 8px rgba(0,0,0,0.04)",
      transform: open ? "translateY(-1px)" : "none"
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, fontWeight: 700, color: "#3a2a1a", marginBottom: 6 }}>
            {recipe.name}
          </div>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {(recipe.tags || []).slice(0, 3).map(t => <Tag key={t} label={t} />)}
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }} onClick={e => e.stopPropagation()}>
          <button onClick={() => onEdit(recipe)} style={{ background: "none", border: "none", cursor: "pointer", color: "#a0784a", padding: 4, opacity: 0.7 }}><Icon name="edit" size={15} /></button>
          <button onClick={() => onDelete(recipe.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0604a", padding: 4, opacity: 0.7 }}><Icon name="trash" size={15} /></button>
        </div>
      </div>
      {open && (recipe.ingredients || recipe.instructions) && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid rgba(200,180,140,0.25)" }}>
          {recipe.ingredients && <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#a0784a", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 4 }}>Ingredients</div>
            <div style={{ fontSize: 14, color: "#5a4a3a", lineHeight: 1.6 }}>{recipe.ingredients}</div>
          </div>}
          {recipe.instructions && <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#a0784a", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 4 }}>Instructions</div>
            <div style={{ fontSize: 14, color: "#5a4a3a", lineHeight: 1.6 }}>{recipe.instructions}</div>
          </div>}
        </div>
      )}
    </div>
  );
};

// ─── Recipe Form Modal ────────────────────────────────────────────────────────
const RecipeModal = ({ recipe, onSave, onClose }) => {
  const [form, setForm] = useState(recipe || { name: "", ingredients: "", instructions: "", tags: [] });
  const [tagInput, setTagInput] = useState((recipe?.tags || []).join(", "));

  const handleSave = () => {
    if (!form.name.trim()) return;
    const tags = tagInput.split(",").map(t => t.trim()).filter(Boolean);
    onSave({ ...form, tags, id: form.id || Date.now().toString() });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(30,20,10,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
      <div style={{ background: "#fffdf5", borderRadius: 18, padding: 28, width: "100%", maxWidth: 520, maxHeight: "85vh", overflowY: "auto", boxShadow: "0 24px 80px rgba(0,0,0,0.18)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#3a2a1a", margin: 0 }}>{recipe ? "Edit Recipe" : "Add Recipe"}</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#888" }}><Icon name="x" /></button>
        </div>
        {[["Recipe Name", "name", "text", true], ["Ingredients", "ingredients", "textarea"], ["Instructions", "instructions", "textarea"]].map(([label, field, type, required]) => (
          <div key={field} style={{ marginBottom: 16 }}>
            <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: "#a0784a", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 6 }}>{label}{required && " *"}</label>
            {type === "textarea"
              ? <textarea value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} rows={4} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid rgba(200,180,140,0.4)", background: "#fff", fontSize: 14, color: "#3a2a1a", resize: "vertical", boxSizing: "border-box", fontFamily: "inherit", outline: "none" }} />
              : <input value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid rgba(200,180,140,0.4)", background: "#fff", fontSize: 14, color: "#3a2a1a", boxSizing: "border-box", outline: "none" }} />}
          </div>
        ))}
        <div style={{ marginBottom: 22 }}>
          <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: "#a0784a", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 6 }}>Tags (comma-separated)</label>
          <input value={tagInput} onChange={e => setTagInput(e.target.value)} placeholder="e.g. dinner, chicken, quick" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid rgba(200,180,140,0.4)", background: "#fff", fontSize: 14, color: "#3a2a1a", boxSizing: "border-box", outline: "none" }} />
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button onClick={onClose} style={{ padding: "10px 20px", borderRadius: 10, border: "1.5px solid rgba(200,180,140,0.4)", background: "none", color: "#7a6a5a", fontSize: 14, cursor: "pointer" }}>Cancel</button>
          <button onClick={handleSave} style={{ padding: "10px 22px", borderRadius: 10, background: "#a0784a", color: "#fff", border: "none", fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", gap: 7, alignItems: "center" }}><Icon name="save" size={15} /> Save</button>
        </div>
      </div>
    </div>
  );
};

// ─── Suggestion Card ──────────────────────────────────────────────────────────
const SuggestionCard = ({ item, isNew, onAddToFavourites }) => (
  <div style={{
    background: isNew ? "linear-gradient(135deg, rgba(255,248,235,0.95), rgba(255,255,255,0.9))" : "rgba(255,252,245,0.9)",
    border: isNew ? "1.5px solid rgba(200,160,80,0.4)" : "1px solid rgba(200,180,140,0.3)",
    borderRadius: 14, padding: "18px 20px",
    boxShadow: isNew ? "0 4px 20px rgba(200,160,80,0.1)" : "0 2px 8px rgba(0,0,0,0.04)"
  }}>
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
      <div style={{ flex: 1 }}>
        {isNew && <div style={{ fontSize: 10, fontWeight: 800, color: "#c0884a", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 4 }}>✨ New Idea</div>}
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, fontWeight: 700, color: "#3a2a1a", marginBottom: isNew && item.description ? 6 : 0 }}>
          {isNew ? item.name : item}
        </div>
        {isNew && item.description && <div style={{ fontSize: 13, color: "#7a6a5a", lineHeight: 1.5 }}>{item.description}</div>}
        {isNew && (item.tags || []).length > 0 && (
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginTop: 8 }}>
            {item.tags.map(t => <Tag key={t} label={t} />)}
          </div>
        )}
      </div>
      {isNew && (
        <button onClick={() => onAddToFavourites(item)} style={{ background: "#a0784a", color: "#fff", border: "none", borderRadius: 99, padding: "6px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap" }}>+ Add</button>
      )}
    </div>
  </div>
);

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("list"); // list | suggest | new
  const [recipes, setRecipes] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editRecipe, setEditRecipe] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [newSuggestions, setNewSuggestions] = useState([]);
  const [suggesting, setSuggesting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importMsg, setImportMsg] = useState("");
  const fileRef = useRef();

  // Load mammoth.js for Word doc parsing
  useEffect(() => {
    if (!window.mammoth) {
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js";
      document.head.appendChild(s);
    }
    loadRecipes().then(r => { setRecipes(r); setLoading(false); });
    loadHistory().then(h => setHistory(h));
  }, []);

  // Load Google Font
  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Lato:wght@300;400;700&display=swap";
    document.head.appendChild(link);
  }, []);

  const saveAndUpdate = async (updated) => {
    setRecipes(updated);
    await saveRecipes(updated);
  };

  const handleSaveRecipe = async (recipe) => {
    const existing = recipes.findIndex(r => r.id === recipe.id);
    const updated = existing >= 0
      ? recipes.map(r => r.id === recipe.id ? recipe : r)
      : [...recipes, recipe];
    await saveAndUpdate(updated);
    setShowForm(false);
    setEditRecipe(null);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this recipe?")) return;
    await saveAndUpdate(recipes.filter(r => r.id !== id));
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImporting(true);
    setImportMsg("Reading document…");
    const text = await parseDocx(file);
    if (!text) { setImportMsg("Could not read file."); setImporting(false); return; }
    setImportMsg("Parsing recipes with AI…");
    const parsed = await parseRecipesFromText(text);
    if (!parsed.length) { setImportMsg("No recipes found."); setImporting(false); return; }
    const withIds = parsed.map((r, i) => ({ ...r, id: `imported-${Date.now()}-${i}` }));
    const merged = [...recipes];
    for (const r of withIds) {
      if (!merged.find(x => x.name.toLowerCase() === r.name.toLowerCase())) merged.push(r);
    }
    await saveAndUpdate(merged);
    setImportMsg(`✓ Imported ${withIds.length} recipes!`);
    setImporting(false);
    setTimeout(() => setImportMsg(""), 3000);
    e.target.value = "";
  };

  const handleSuggest = async () => {
    if (!recipes.length) return;
    setSuggesting(true);
    setSuggestions([]);
    const recent = history.slice(-12);
    const names = await suggestFromFamily(recipes, recent);
    setSuggestions(names);
    const newHistory = [...history, ...names];
    setHistory(newHistory);
    await saveHistory(newHistory);
    setSuggesting(false);
  };

  const handleSuggestNew = async () => {
    setSuggesting(true);
    setNewSuggestions([]);
    const ideas = await suggestNewRecipes(recipes.map(r => r.name));
    setNewSuggestions(ideas);
    setSuggesting(false);
  };

  const handleAddNewToFavourites = async (item) => {
    const recipe = { id: Date.now().toString(), name: item.name, ingredients: "", instructions: item.description || "", tags: item.tags || [] };
    await saveAndUpdate([...recipes, recipe]);
    setNewSuggestions(ns => ns.filter(n => n.name !== item.name));
  };

  const filtered = recipes.filter(r =>
    r.name.toLowerCase().includes(search.toLowerCase()) ||
    (r.tags || []).some(t => t.toLowerCase().includes(search.toLowerCase()))
  );

  const navBtn = (id, icon, label) => (
    <button key={id} onClick={() => setTab(id)} style={{
      flex: 1, padding: "10px 4px", background: tab === id ? "#a0784a" : "none",
      border: "none", borderRadius: 10, cursor: "pointer",
      color: tab === id ? "#fff" : "#7a6a5a", fontFamily: "'Lato', sans-serif",
      fontSize: 12, fontWeight: 700, display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
      transition: "all 0.18s"
    }}>
      <Icon name={icon} size={18} />
      {label}
    </button>
  );

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #fdf8f0 0%, #f5ebe0 50%, #ede0cc 100%)", fontFamily: "'Lato', sans-serif" }}>
      {/* Header */}
      <div style={{ background: "rgba(255,252,245,0.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(200,180,140,0.25)", padding: "20px 24px 16px", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 640, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#a0784a", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 2 }}>Family</div>
              <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, fontWeight: 800, color: "#3a2a1a", margin: 0, lineHeight: 1 }}>Favourites</h1>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: "#a0784a", fontFamily: "'Playfair Display', serif" }}>{recipes.length}</div>
              <div style={{ fontSize: 11, color: "#9a8a7a" }}>recipes</div>
            </div>
          </div>
          {/* Nav */}
          <div style={{ display: "flex", gap: 4, background: "rgba(200,180,140,0.12)", borderRadius: 12, padding: 4 }}>
            {navBtn("list", "book", "All Recipes")}
            {navBtn("suggest", "wand", "Suggest")}
            {navBtn("new", "star", "New Ideas")}
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "20px 16px 80px" }}>

        {/* ── LIST TAB ── */}
        {tab === "list" && (
          <div>
            {/* Import + Add */}
            <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
              <button onClick={() => fileRef.current.click()} disabled={importing} style={{
                flex: 1, padding: "11px 16px", background: "rgba(255,252,245,0.9)", border: "1.5px dashed rgba(160,120,74,0.4)",
                borderRadius: 12, cursor: "pointer", color: "#a0784a", fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", gap: 7
              }}>
                <Icon name="upload" size={16} /> {importing ? "Importing…" : "Import Word Doc"}
              </button>
              <input ref={fileRef} type="file" accept=".docx,.doc" onChange={handleImport} style={{ display: "none" }} />
              <button onClick={() => { setEditRecipe(null); setShowForm(true); }} style={{
                padding: "11px 18px", background: "#a0784a", color: "#fff", border: "none",
                borderRadius: 12, cursor: "pointer", fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", gap: 6
              }}>
                <Icon name="plus" size={16} /> Add
              </button>
            </div>

            {importMsg && (
              <div style={{ background: importMsg.startsWith("✓") ? "rgba(80,160,80,0.1)" : "rgba(200,100,80,0.1)", border: `1px solid ${importMsg.startsWith("✓") ? "rgba(80,160,80,0.3)" : "rgba(200,100,80,0.3)"}`, borderRadius: 10, padding: "10px 14px", marginBottom: 14, fontSize: 14, color: importMsg.startsWith("✓") ? "#3a8a3a" : "#a04030" }}>
                {importMsg}
              </div>
            )}

            {/* Search */}
            <div style={{ position: "relative", marginBottom: 16 }}>
              <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#b0987a" }}><Icon name="search" size={16} /></span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search recipes or tags…" style={{ width: "100%", padding: "11px 12px 11px 38px", borderRadius: 12, border: "1.5px solid rgba(200,180,140,0.35)", background: "rgba(255,252,245,0.9)", fontSize: 14, color: "#3a2a1a", boxSizing: "border-box", outline: "none" }} />
            </div>

            {loading ? (
              <div style={{ textAlign: "center", padding: 40, color: "#a0784a" }}>Loading…</div>
            ) : filtered.length === 0 ? (
              <div style={{ textAlign: "center", padding: 48 }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📖</div>
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#7a6a5a", marginBottom: 8 }}>{search ? "No matches found" : "No recipes yet"}</div>
                <div style={{ fontSize: 14, color: "#9a8a7a" }}>{search ? "Try a different search" : "Import a Word doc or add your first recipe"}</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {filtered.map(r => <RecipeCard key={r.id} recipe={r} onEdit={r => { setEditRecipe(r); setShowForm(true); }} onDelete={handleDelete} />)}
              </div>
            )}
          </div>
        )}

        {/* ── SUGGEST TAB ── */}
        {tab === "suggest" && (
          <div>
            <div style={{ background: "rgba(255,252,245,0.9)", borderRadius: 16, padding: "20px 22px", marginBottom: 18, border: "1px solid rgba(200,180,140,0.3)" }}>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#3a2a1a", margin: "0 0 6px" }}>What's for dinner?</h2>
              <p style={{ fontSize: 14, color: "#7a6a5a", margin: "0 0 16px", lineHeight: 1.5 }}>Get 4 suggestions from your Family Favourites, varied from recent picks.</p>
              <button onClick={handleSuggest} disabled={suggesting || !recipes.length} style={{
                width: "100%", padding: "13px", background: "#a0784a", color: "#fff", border: "none",
                borderRadius: 12, cursor: "pointer", fontWeight: 700, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                opacity: suggesting || !recipes.length ? 0.6 : 1
              }}>
                <Icon name={suggesting ? "refresh" : "wand"} size={17} />
                {suggesting ? "Finding suggestions…" : "Suggest Recipes"}
              </button>
            </div>

            {suggestions.length > 0 && (
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#a0784a", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>Tonight's picks</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {suggestions.map((s, i) => <SuggestionCard key={i} item={s} isNew={false} />)}
                </div>
                <div style={{ marginTop: 14, fontSize: 13, color: "#9a8a7a", textAlign: "center" }}>Tap "Suggest Recipes" again for different picks</div>
              </div>
            )}

            {!recipes.length && (
              <div style={{ textAlign: "center", padding: 30, color: "#9a8a7a", fontSize: 14 }}>Add some recipes first to get suggestions.</div>
            )}
          </div>
        )}

        {/* ── NEW IDEAS TAB ── */}
        {tab === "new" && (
          <div>
            <div style={{ background: "linear-gradient(135deg, rgba(255,248,235,0.95), rgba(255,255,255,0.9))", borderRadius: 16, padding: "20px 22px", marginBottom: 18, border: "1.5px solid rgba(200,160,80,0.35)" }}>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#3a2a1a", margin: "0 0 6px" }}>Discover New Recipes</h2>
              <p style={{ fontSize: 14, color: "#7a6a5a", margin: "0 0 16px", lineHeight: 1.5 }}>AI-powered ideas outside your current collection. Add any you like!</p>
              <button onClick={handleSuggestNew} disabled={suggesting} style={{
                width: "100%", padding: "13px", background: "linear-gradient(135deg, #c0884a, #a0684a)", color: "#fff", border: "none",
                borderRadius: 12, cursor: "pointer", fontWeight: 700, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                opacity: suggesting ? 0.6 : 1
              }}>
                <Icon name={suggesting ? "refresh" : "star"} size={17} />
                {suggesting ? "Discovering ideas…" : "Find New Ideas"}
              </button>
            </div>

            {newSuggestions.length > 0 && (
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#c0884a", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>New recipe ideas</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {newSuggestions.map((s, i) => <SuggestionCard key={i} item={s} isNew={true} onAddToFavourites={handleAddNewToFavourites} />)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Recipe Form Modal */}
      {showForm && (
        <RecipeModal
          recipe={editRecipe}
          onSave={handleSaveRecipe}
          onClose={() => { setShowForm(false); setEditRecipe(null); }}
        />
      )}
    </div>
  );
}
