import { useState, useEffect, useRef } from "react";

// ── Styles ────────────────────────────────────────────────────────────────────
const CSS = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --cream: #fdf6ed;
    --tan: #f0e4d0;
    --primary: #a0784a;
    --primary-dark: #7a5a35;
    --accent: #c0522a;
    --text: #3a2a1a;
    --text-light: #7a6050;
    --card-bg: #fffaf4;
    --border: #ddd0bb;
    --shadow: 0 2px 12px rgba(100,60,20,0.10);
    --shadow-lg: 0 8px 32px rgba(100,60,20,0.16);
    --radius: 14px;
    --tag-bg: #f3e8d8;
    --tag-color: #7a5a35;
  }

  body {
    font-family: 'Lato', sans-serif;
    background: linear-gradient(160deg, var(--cream) 0%, var(--tan) 100%);
    min-height: 100vh;
    color: var(--text);
  }

  /* ── Layout ── */
  .app { max-width: 820px; margin: 0 auto; padding: 0 16px 100px; }

  .header {
    padding: 32px 0 20px;
    text-align: center;
    border-bottom: 1px solid var(--border);
    margin-bottom: 24px;
  }
  .header h1 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    font-weight: 700;
    color: var(--primary-dark);
    letter-spacing: -0.5px;
    line-height: 1.1;
  }
  .header h1 span { color: var(--accent); font-style: italic; }
  .header p { font-size: 0.9rem; color: var(--text-light); margin-top: 4px; letter-spacing: 0.04em; }

  /* ── Tabs ── */
  .tabs {
    display: flex;
    gap: 4px;
    background: var(--tan);
    border-radius: 12px;
    padding: 4px;
    margin-bottom: 24px;
    overflow-x: auto;
  }
  .tab-btn {
    flex: 1;
    min-width: 80px;
    padding: 9px 8px;
    border: none;
    background: transparent;
    border-radius: 9px;
    font-family: 'Lato', sans-serif;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--text-light);
    cursor: pointer;
    transition: all 0.18s;
    white-space: nowrap;
    letter-spacing: 0.03em;
    text-transform: uppercase;
  }
  .tab-btn.active {
    background: var(--card-bg);
    color: var(--primary-dark);
    box-shadow: var(--shadow);
  }
  .tab-btn:hover:not(.active) { color: var(--primary); background: rgba(255,255,255,0.5); }

  /* ── Search ── */
  .search-bar {
    position: relative;
    margin-bottom: 20px;
  }
  .search-bar input {
    width: 100%;
    padding: 11px 16px 11px 42px;
    border: 1.5px solid var(--border);
    border-radius: var(--radius);
    background: var(--card-bg);
    font-family: 'Lato', sans-serif;
    font-size: 0.95rem;
    color: var(--text);
    transition: border-color 0.18s;
  }
  .search-bar input:focus { outline: none; border-color: var(--primary); }
  .search-bar .icon {
    position: absolute; left: 14px; top: 50%; transform: translateY(-50%);
    color: var(--text-light); font-size: 1.1rem; pointer-events: none;
  }

  /* ── Recipe Cards ── */
  .recipe-list { display: flex; flex-direction: column; gap: 12px; }

  .recipe-card {
    background: var(--card-bg);
    border: 1.5px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    transition: box-shadow 0.18s, transform 0.18s;
  }
  .recipe-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-1px); }

  .recipe-card-header {
    display: flex;
    align-items: center;
    padding: 16px 18px;
    cursor: pointer;
    gap: 12px;
  }
  .recipe-card-header .emoji { font-size: 1.6rem; flex-shrink: 0; }
  .recipe-card-header .info { flex: 1; min-width: 0; }
  .recipe-card-header h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.08rem;
    font-weight: 600;
    color: var(--text);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .recipe-card-header .meta { font-size: 0.78rem; color: var(--text-light); margin-top: 2px; }
  .recipe-card-header .actions { display: flex; gap: 6px; flex-shrink: 0; }
  .recipe-card-header .chevron { color: var(--text-light); transition: transform 0.2s; font-size: 1.1rem; }
  .recipe-card-header .chevron.open { transform: rotate(180deg); }

  .recipe-body {
    padding: 0 18px 18px;
    border-top: 1px solid var(--border);
  }
  .recipe-section { margin-top: 14px; }
  .recipe-section h4 {
    font-family: 'Playfair Display', serif;
    font-size: 0.88rem;
    font-weight: 600;
    color: var(--primary-dark);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 6px;
  }
  .recipe-section p, .recipe-section ul {
    font-size: 0.9rem;
    line-height: 1.6;
    color: var(--text);
  }
  .recipe-section ul { padding-left: 18px; }
  .recipe-section ul li { margin-bottom: 3px; }

  .tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }
  .tag {
    background: var(--tag-bg);
    color: var(--tag-color);
    font-size: 0.72rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 20px;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  /* ── Buttons ── */
  .btn {
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-family: 'Lato', sans-serif;
    font-size: 0.82rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s;
    letter-spacing: 0.03em;
  }
  .btn-primary { background: var(--primary); color: white; }
  .btn-primary:hover { background: var(--primary-dark); }
  .btn-accent { background: var(--accent); color: white; }
  .btn-accent:hover { background: #a03a1a; }
  .btn-ghost {
    background: transparent;
    border: 1.5px solid var(--border);
    color: var(--text-light);
  }
  .btn-ghost:hover { border-color: var(--primary); color: var(--primary); }
  .btn-danger { background: #e05040; color: white; }
  .btn-danger:hover { background: #c03020; }
  .btn-sm { padding: 5px 10px; font-size: 0.75rem; }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }

  /* ── FAB ── */
  .fab {
    position: fixed;
    bottom: 28px; right: 24px;
    width: 56px; height: 56px;
    border-radius: 50%;
    background: var(--primary);
    color: white;
    border: none;
    font-size: 1.8rem;
    box-shadow: 0 4px 18px rgba(100,60,20,0.3);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.18s;
    z-index: 100;
  }
  .fab:hover { background: var(--primary-dark); transform: scale(1.08); }

  /* ── Modal ── */
  .modal-overlay {
    position: fixed; inset: 0;
    background: rgba(40,20,5,0.45);
    display: flex; align-items: center; justify-content: center;
    z-index: 200;
    padding: 16px;
  }
  .modal {
    background: var(--cream);
    border-radius: 18px;
    padding: 28px 24px;
    width: 100%; max-width: 560px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: var(--shadow-lg);
  }
  .modal h2 {
    font-family: 'Playfair Display', serif;
    font-size: 1.4rem;
    color: var(--primary-dark);
    margin-bottom: 20px;
  }
  .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }

  /* ── Form ── */
  .form-group { margin-bottom: 16px; }
  .form-group label {
    display: block;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--text-light);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 5px;
  }
  .form-group input,
  .form-group textarea,
  .form-group select {
    width: 100%;
    padding: 10px 13px;
    border: 1.5px solid var(--border);
    border-radius: 9px;
    background: var(--card-bg);
    font-family: 'Lato', sans-serif;
    font-size: 0.92rem;
    color: var(--text);
    transition: border-color 0.18s;
    resize: vertical;
  }
  .form-group input:focus,
  .form-group textarea:focus { outline: none; border-color: var(--primary); }
  .form-group textarea { min-height: 100px; }

  /* ── AI Panels ── */
  .ai-section {
    background: var(--card-bg);
    border: 1.5px solid var(--border);
    border-radius: var(--radius);
    padding: 20px;
    margin-bottom: 16px;
  }
  .ai-section h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.1rem;
    color: var(--primary-dark);
    margin-bottom: 8px;
  }
  .ai-section p { font-size: 0.88rem; color: var(--text-light); line-height: 1.55; margin-bottom: 14px; }

  .suggestion-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  @media (max-width: 500px) { .suggestion-grid { grid-template-columns: 1fr; } }

  .suggestion-card {
    background: var(--cream);
    border: 1.5px solid var(--border);
    border-radius: 10px;
    padding: 14px;
    display: flex; flex-direction: column; gap: 8px;
  }
  .suggestion-card h4 {
    font-family: 'Playfair Display', serif;
    font-size: 0.98rem;
    color: var(--text);
  }
  .suggestion-card p { font-size: 0.82rem; color: var(--text-light); line-height: 1.5; flex: 1; }
  .suggestion-card .card-actions { display: flex; gap: 6px; flex-wrap: wrap; }

  .loading-dots span {
    display: inline-block;
    animation: blink 1.2s infinite;
    font-size: 1.4rem;
    color: var(--primary);
  }
  .loading-dots span:nth-child(2) { animation-delay: 0.2s; }
  .loading-dots span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes blink { 0%,80%,100%{opacity:0} 40%{opacity:1} }

  .empty-state {
    text-align: center;
    padding: 48px 20px;
    color: var(--text-light);
  }
  .empty-state .icon { font-size: 3rem; margin-bottom: 12px; }
  .empty-state h3 { font-family: 'Playfair Display', serif; font-size: 1.2rem; color: var(--primary-dark); margin-bottom: 6px; }
  .empty-state p { font-size: 0.88rem; }

  .toast {
    position: fixed;
    bottom: 96px; left: 50%; transform: translateX(-50%);
    background: var(--primary-dark);
    color: white;
    padding: 10px 22px;
    border-radius: 30px;
    font-size: 0.88rem;
    font-weight: 700;
    z-index: 300;
    box-shadow: var(--shadow-lg);
    animation: slideUp 0.25s ease, fadeOut 0.4s ease 2.2s forwards;
    white-space: nowrap;
  }
  @keyframes slideUp { from{transform:translateX(-50%) translateY(20px);opacity:0} to{transform:translateX(-50%) translateY(0);opacity:1} }
  @keyframes fadeOut { to{opacity:0;transform:translateX(-50%) translateY(-10px)} }

  .divider { height: 1px; background: var(--border); margin: 20px 0; }

  .upload-area {
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 32px;
    text-align: center;
    cursor: pointer;
    transition: border-color 0.18s, background 0.18s;
    background: var(--card-bg);
  }
  .upload-area:hover { border-color: var(--primary); background: var(--tan); }
  .upload-area .icon { font-size: 2.5rem; margin-bottom: 10px; }
  .upload-area p { font-size: 0.88rem; color: var(--text-light); }
  .upload-area strong { color: var(--primary); }

  .progress-bar {
    height: 4px;
    background: var(--border);
    border-radius: 2px;
    margin: 12px 0;
    overflow: hidden;
  }
  .progress-bar-fill {
    height: 100%;
    background: var(--primary);
    border-radius: 2px;
    transition: width 0.3s;
  }
`;

// ── Helpers ───────────────────────────────────────────────────────────────────
const RECIPE_EMOJIS = ["🍲", "🥘", "🍝", "🥗", "🍜", "🥩", "🍗", "🥧", "🍛", "🫕", "🍱", "🥙", "🫔", "🥚", "🍳", "🥞"];
const randomEmoji = () => RECIPE_EMOJIS[Math.floor(Math.random() * RECIPE_EMOJIS.length)];

function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
}

async function callClaude(messages, system = "", tools = null) {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    messages,
  };
  if (system) body.system = system;
  if (tools) body.tools = tools;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await resp.json();
  const text = data.content?.filter(b => b.type === "text").map(b => b.text).join("\n") || "";
  return text;
}

// ── Storage helpers ───────────────────────────────────────────────────────────
async function loadRecipes() {
  try {
    const r = await window.storage.get("recipes");
    return r ? JSON.parse(r.value) : [];
  } catch { return []; }
}
async function saveRecipes(list) {
  await window.storage.set("recipes", JSON.stringify(list));
}
async function loadSuggestHistory() {
  try {
    const r = await window.storage.get("suggest-history");
    return r ? JSON.parse(r.value) : [];
  } catch { return []; }
}
async function saveSuggestHistory(h) {
  await window.storage.set("suggest-history", JSON.stringify(h));
}

// ── Sub-components ────────────────────────────────────────────────────────────
function RecipeCard({ recipe, onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const ingList = recipe.ingredients
    ? recipe.ingredients.split("\n").filter(Boolean)
    : [];

  return (
    <div className="recipe-card">
      <div className="recipe-card-header" onClick={() => setOpen(o => !o)}>
        <span className="emoji">{recipe.emoji || "🍲"}</span>
        <div className="info">
          <h3>{recipe.name}</h3>
          <div className="meta">
            {recipe.tags?.length ? recipe.tags.slice(0, 3).join(" · ") : "Family favourite"}
          </div>
        </div>
        <div className="actions" onClick={e => e.stopPropagation()}>
          <button className="btn btn-ghost btn-sm" onClick={() => onEdit(recipe)}>✏️</button>
          <button className="btn btn-danger btn-sm" onClick={() => onDelete(recipe.id)}>🗑</button>
        </div>
        <span className={`chevron ${open ? "open" : ""}`}>▾</span>
      </div>
      {open && (
        <div className="recipe-body">
          {ingList.length > 0 && (
            <div className="recipe-section">
              <h4>Ingredients</h4>
              <ul>{ingList.map((i, idx) => <li key={idx}>{i}</li>)}</ul>
            </div>
          )}
          {recipe.instructions && (
            <div className="recipe-section">
              <h4>Instructions</h4>
              <p style={{ whiteSpace: "pre-line" }}>{recipe.instructions}</p>
            </div>
          )}
          {recipe.tags?.length > 0 && (
            <div className="tags">
              {recipe.tags.map(t => <span key={t} className="tag">{t}</span>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function RecipeForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(initial || {
    name: "", ingredients: "", instructions: "", tags: "",
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = () => {
    if (!form.name.trim()) return;
    onSave({
      id: initial?.id || `r-${Date.now()}`,
      emoji: initial?.emoji || randomEmoji(),
      name: form.name.trim(),
      ingredients: form.ingredients.trim(),
      instructions: form.instructions.trim(),
      tags: form.tags ? form.tags.split(",").map(t => t.trim()).filter(Boolean) : [],
      createdAt: initial?.createdAt || Date.now(),
    });
  };

  return (
    <div>
      <div className="form-group">
        <label>Recipe Name *</label>
        <input value={form.name} onChange={e => set("name", e.target.value)} placeholder="e.g. Grandma's Chicken Stew" />
      </div>
      <div className="form-group">
        <label>Ingredients (one per line)</label>
        <textarea
          value={form.ingredients}
          onChange={e => set("ingredients", e.target.value)}
          placeholder={"500g chicken breast\n2 cups chicken broth\n..."}
          rows={5}
        />
      </div>
      <div className="form-group">
        <label>Instructions</label>
        <textarea
          value={form.instructions}
          onChange={e => set("instructions", e.target.value)}
          placeholder="Step by step cooking instructions..."
          rows={5}
        />
      </div>
      <div className="form-group">
        <label>Tags (comma separated)</label>
        <input value={form.tags} onChange={e => set("tags", e.target.value)} placeholder="e.g. chicken, soup, winter" />
      </div>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn btn-primary" onClick={handleSave} disabled={!form.name.trim()}>Save Recipe</button>
      </div>
    </div>
  );
}

function LoadingDots() {
  return <div className="loading-dots"><span>●</span><span>●</span><span>●</span></div>;
}

// ── Tabs ──────────────────────────────────────────────────────────────────────

function AllRecipesTab({ recipes, onEdit, onDelete }) {
  const [query, setQuery] = useState("");
  const filtered = recipes.filter(r =>
    r.name.toLowerCase().includes(query.toLowerCase()) ||
    r.tags?.some(t => t.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div>
      <div className="search-bar">
        <span className="icon">🔍</span>
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search recipes or tags…"
        />
      </div>
      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="icon">📖</div>
          <h3>{recipes.length === 0 ? "No recipes yet" : "Nothing found"}</h3>
          <p>{recipes.length === 0 ? "Tap + to add your first family favourite!" : "Try a different search term."}</p>
        </div>
      ) : (
        <div className="recipe-list">
          {filtered.map(r => (
            <RecipeCard key={r.id} recipe={r} onEdit={onEdit} onDelete={onDelete} />
          ))}
        </div>
      )}
    </div>
  );
}

function SuggestTab({ recipes }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const getSuggestions = async () => {
    if (recipes.length === 0) { setError("Add some recipes first!"); return; }
    setLoading(true); setError(""); setSuggestions([]);
    try {
      const history = await loadSuggestHistory();
      const names = recipes.map(r => r.name);
      const avoid = history.slice(-12);
      const prompt = `You are a helpful family meal planner. From this list of family favourite recipes, pick 4 to suggest for this week's meals. Avoid suggesting these recently suggested recipes: ${avoid.join(", ") || "none"}.

Available recipes: ${names.join(", ")}

Respond ONLY with a JSON array of exactly 4 recipe names from the list, no explanation, no markdown fences, just the raw JSON array. Example: ["Recipe 1","Recipe 2","Recipe 3","Recipe 4"]`;

      const text = await callClaude([{ role: "user", content: prompt }]);
      const clean = text.replace(/```json|```/g, "").trim();
      const picked = JSON.parse(clean);
      const result = picked
        .map(name => recipes.find(r => r.name === name))
        .filter(Boolean)
        .slice(0, 4);
      setSuggestions(result);
      await saveSuggestHistory([...history, ...picked].slice(-30));
    } catch (e) {
      setError("Couldn't get suggestions. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="ai-section">
        <h3>🎲 Weekly Meal Suggestions</h3>
        <p>Let the AI pick 4 recipes from your collection for this week — it remembers what it suggested recently to keep things fresh.</p>
        <button className="btn btn-primary" onClick={getSuggestions} disabled={loading || recipes.length === 0}>
          {loading ? "Thinking…" : "Suggest 4 Meals"}
        </button>
        {recipes.length === 0 && <p style={{marginTop:"8px",color:"var(--accent)"}}>Add recipes first!</p>}
      </div>

      {loading && (
        <div style={{ textAlign: "center", padding: "32px" }}>
          <LoadingDots />
          <p style={{ marginTop: "12px", color: "var(--text-light)", fontSize: "0.88rem" }}>Picking your meals…</p>
        </div>
      )}

      {error && <p style={{ color: "var(--accent)", textAlign: "center", padding: "16px" }}>{error}</p>}

      {suggestions.length > 0 && (
        <div>
          <p style={{ fontSize: "0.82rem", color: "var(--text-light)", marginBottom: "12px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>This week's suggestions</p>
          <div className="suggestion-grid">
            {suggestions.map(r => (
              <div key={r.id} className="suggestion-card">
                <div style={{ fontSize: "1.6rem" }}>{r.emoji}</div>
                <h4>{r.name}</h4>
                {r.tags?.length > 0 && (
                  <div className="tags">
                    {r.tags.slice(0, 3).map(t => <span key={t} className="tag">{t}</span>)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function NewIdeasTab({ recipes, onAdd }) {
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [theme, setTheme] = useState("");

  const getIdeas = async () => {
    setLoading(true); setError(""); setIdeas([]);
    try {
      const existing = recipes.map(r => r.name).join(", ");
      const prompt = `You are a creative family cooking advisor. Suggest 4 new recipe ideas that are NOT in this existing collection: ${existing || "none yet"}.
${theme ? `Theme or preference: ${theme}` : "Suggest a variety of family-friendly meals."}

Respond ONLY with a valid JSON array of 4 objects, no markdown fences. Each object:
{"name":"Recipe Name","description":"1-2 sentence description","ingredients":"ingredient1\ningredient2\ningredient3","instructions":"Brief overview of how to cook it","tags":["tag1","tag2"]}`;

      const text = await callClaude([{ role: "user", content: prompt }]);
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setIdeas(parsed.slice(0, 4));
    } catch (e) {
      setError("Couldn't generate ideas. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const addIdea = (idea) => {
    const recipe = {
      id: `r-${Date.now()}-${Math.random()}`,
      emoji: randomEmoji(),
      name: idea.name,
      ingredients: idea.ingredients || "",
      instructions: idea.instructions || "",
      tags: idea.tags || [],
      createdAt: Date.now(),
    };
    onAdd(recipe);
  };

  return (
    <div>
      <div className="ai-section">
        <h3>✨ New Recipe Ideas</h3>
        <p>Get AI suggestions for recipes outside your current collection. Add any you love to Family Favourites!</p>
        <div className="form-group" style={{ marginBottom: "12px" }}>
          <input
            value={theme}
            onChange={e => setTheme(e.target.value)}
            placeholder="Optional theme: e.g. 'quick weeknight', 'Asian-inspired', 'vegetarian'…"
          />
        </div>
        <button className="btn btn-accent" onClick={getIdeas} disabled={loading}>
          {loading ? "Generating…" : "Get New Ideas"}
        </button>
      </div>

      {loading && (
        <div style={{ textAlign: "center", padding: "32px" }}>
          <LoadingDots />
          <p style={{ marginTop: "12px", color: "var(--text-light)", fontSize: "0.88rem" }}>Dreaming up ideas…</p>
        </div>
      )}

      {error && <p style={{ color: "var(--accent)", textAlign: "center", padding: "16px" }}>{error}</p>}

      {ideas.length > 0 && (
        <div className="suggestion-grid">
          {ideas.map((idea, i) => (
            <div key={i} className="suggestion-card">
              <h4>{idea.name}</h4>
              <p>{idea.description}</p>
              {idea.tags?.length > 0 && (
                <div className="tags">
                  {idea.tags.slice(0, 3).map(t => <span key={t} className="tag">{t}</span>)}
                </div>
              )}
              <div className="card-actions">
                <button className="btn btn-primary btn-sm" onClick={() => addIdea(idea)}>+ Add to Favourites</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ImportTab({ onImport }) {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const [parsed, setParsed] = useState([]);
  const fileRef = useRef();

  const handleFile = async (file) => {
    if (!file) return;
    setLoading(true); setParsed([]); setProgress(10); setStatus("Reading document…");

    try {
      // Read docx as base64
      const base64 = await new Promise((res, rej) => {
        const reader = new FileReader();
        reader.onload = () => res(reader.result.split(",")[1]);
        reader.onerror = () => rej();
        reader.readAsDataURL(file);
      });

      setProgress(30); setStatus("Sending to AI…");

      const prompt = `This is a Word document (.docx) containing family recipes. Please extract ALL recipes from this document.

Respond ONLY with a valid JSON array of recipe objects, no markdown fences. Each object:
{"name":"Recipe Name","ingredients":"ingredient1\ningredient2","instructions":"step by step instructions","tags":["tag1","tag2"]}

If you cannot read the document or find no recipes, return an empty array: []`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: [
              {
                type: "document",
                source: { type: "base64", media_type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", data: base64 }
              },
              { type: "text", text: prompt }
            ]
          }]
        })
      });

      setProgress(70); setStatus("Parsing recipes…");
      const data = await response.json();
      const text = data.content?.filter(b => b.type === "text").map(b => b.text).join("\n") || "[]";
      const clean = text.replace(/```json|```/g, "").trim();
      const recipes = JSON.parse(clean);
      setProgress(100);
      setStatus(`Found ${recipes.length} recipe${recipes.length !== 1 ? "s" : ""}!`);
      setParsed(recipes.map((r, i) => ({
        id: `r-import-${Date.now()}-${i}`,
        emoji: randomEmoji(),
        ...r,
        tags: r.tags || [],
        createdAt: Date.now(),
      })));
    } catch (e) {
      setStatus("Failed to parse document. Make sure it's a valid .docx file.");
    } finally {
      setLoading(false);
    }
  };

  const importAll = () => {
    parsed.forEach(r => onImport(r));
    setParsed([]); setStatus(""); setProgress(0);
  };

  return (
    <div>
      <div className="ai-section">
        <h3>📄 Import from Word Doc</h3>
        <p>Upload a .docx file and the AI will automatically extract and parse all the recipes it contains.</p>
      </div>

      <div
        className="upload-area"
        onClick={() => fileRef.current?.click()}
        onDragOver={e => e.preventDefault()}
        onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}
      >
        <div className="icon">📂</div>
        <p><strong>Click to upload</strong> or drag & drop</p>
        <p>.docx files only</p>
        <input ref={fileRef} type="file" accept=".docx" style={{ display: "none" }} onChange={e => handleFile(e.target.files[0])} />
      </div>

      {loading && (
        <div style={{ marginTop: "16px" }}>
          <div className="progress-bar">
            <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
          </div>
          <p style={{ fontSize: "0.85rem", color: "var(--text-light)", textAlign: "center" }}>{status}</p>
        </div>
      )}

      {!loading && status && <p style={{ fontSize: "0.88rem", color: "var(--primary)", fontWeight: 700, textAlign: "center", margin: "12px 0" }}>{status}</p>}

      {parsed.length > 0 && (
        <div style={{ marginTop: "16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
            <p style={{ fontSize: "0.82rem", color: "var(--text-light)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>
              Recipes to import
            </p>
            <button className="btn btn-primary" onClick={importAll}>Import All ({parsed.length})</button>
          </div>
          <div className="recipe-list">
            {parsed.map(r => (
              <div key={r.id} className="suggestion-card" style={{ marginBottom: "8px" }}>
                <h4>{r.emoji} {r.name}</h4>
                {r.tags?.length > 0 && <div className="tags">{r.tags.map(t => <span key={t} className="tag">{t}</span>)}</div>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("all");
  const [recipes, setRecipes] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [toast, setToast] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadRecipes().then(r => { setRecipes(r); setLoaded(true); });
  }, []);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2700);
  };

  const persistRecipes = async (list) => {
    setRecipes(list);
    await saveRecipes(list);
  };

  const handleSave = async (recipe) => {
    const exists = recipes.find(r => r.id === recipe.id);
    const next = exists
      ? recipes.map(r => r.id === recipe.id ? recipe : r)
      : [...recipes, recipe];
    await persistRecipes(next);
    setShowForm(false);
    setEditingRecipe(null);
    showToast(exists ? "Recipe updated! ✏️" : "Recipe added! 🎉");
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this recipe?")) return;
    await persistRecipes(recipes.filter(r => r.id !== id));
    showToast("Recipe deleted.");
  };

  const handleEdit = (recipe) => {
    setEditingRecipe({ ...recipe, tags: recipe.tags?.join(", ") || "" });
    setShowForm(true);
  };

  const handleAdd = async (recipe) => {
    const next = [...recipes, recipe];
    await persistRecipes(next);
    showToast(`"${recipe.name}" added! 🌟`);
  };

  const TABS = [
    { id: "all", label: "📖 All Recipes" },
    { id: "suggest", label: "🎲 Suggest" },
    { id: "ideas", label: "✨ New Ideas" },
    { id: "import", label: "📄 Import Doc" },
  ];

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <header className="header">
          <h1>Family <span>Favourites</span></h1>
          <p>{loaded ? `${recipes.length} recipe${recipes.length !== 1 ? "s" : ""} in your collection` : "Loading…"}</p>
        </header>

        <nav className="tabs">
          {TABS.map(t => (
            <button key={t.id} className={`tab-btn ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
              {t.label}
            </button>
          ))}
        </nav>

        {tab === "all" && (
          <AllRecipesTab recipes={recipes} onEdit={handleEdit} onDelete={handleDelete} />
        )}
        {tab === "suggest" && <SuggestTab recipes={recipes} />}
        {tab === "ideas" && <NewIdeasTab recipes={recipes} onAdd={handleAdd} />}
        {tab === "import" && <ImportTab onImport={handleAdd} />}

        {tab === "all" && (
          <button className="fab" onClick={() => { setEditingRecipe(null); setShowForm(true); }} title="Add recipe">＋</button>
        )}

        {showForm && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) { setShowForm(false); setEditingRecipe(null); } }}>
            <div className="modal">
              <h2>{editingRecipe ? "Edit Recipe" : "Add New Recipe"}</h2>
              <RecipeForm
                initial={editingRecipe}
                onSave={handleSave}
                onCancel={() => { setShowForm(false); setEditingRecipe(null); }}
              />
            </div>
          </div>
        )}

        {toast && <div className="toast">{toast}</div>}
      </div>
    </>
  );
}
