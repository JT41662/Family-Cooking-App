# Family Favourites 🍲

A family recipe management web app built with React + Vite, powered by Claude AI.

**Live:** https://jt41662.github.io/Family-Cooking-App/

## Features
- **All Recipes** — browse, search, expand, edit, delete
- **Suggest** — AI picks 4 recipes per week, tracks history to avoid repeats
- **New Ideas** — AI suggests recipes outside your collection
- **Import Doc** — upload .docx, AI extracts recipes automatically

## Tech Stack
- React 18 + Vite 5
- Claude API (claude-sonnet-4-20250514)
- GitHub Pages (via GitHub Actions)
- Persistent storage via `window.storage`

## Setup
```bash
npm install
npm run dev
```

## Deploy
Push to `main` branch — GitHub Actions deploys automatically.

> Settings → Pages → Source → **GitHub Actions** (one-time setup required)
